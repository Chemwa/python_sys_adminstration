print ("welcome to cloud computing:\n")

try:
     f1=open ("/file1.txt")
     print(f1.read())
     f1.close()

except FileNotFoundError:
    print("Error: The file 'file1.txt' was not found. Please check the file path and try again.")
