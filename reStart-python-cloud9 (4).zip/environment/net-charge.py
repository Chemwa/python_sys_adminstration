# Python3.6  
# Coding: utf-8  
# Store the human preproinsulin sequence in a variable called preproinsulin:  
# Store the human preproinsulin sequence in a variable called preproinsulin:
preproInsulin = "malwmrllpllallalwgpdpaaafvnqhlcgshlvealylvcgergffytpktrreaedlqvgqvelgggpgagslqplalegslqkrgiveqcctsicslyqlenycn"

# Store the remaining sequence elements of human insulin in variables:
lsInsulin = "malwmrllpllallalwgpdpaaa"  # L-chain
bInsulin = "fvnqhlcgshlvealylvcgergffytpkt"  # B-chain
aInsulin = "giveqcctsicslyqlenycn"  # A-chain
cInsulin = "rreaedlqvgqvelgggpgagslqplalegslqkr"  # C-peptide
insulin = bInsulin + aInsulin  # The full insulin molecule (B-chain + A-chain)

# pKR values for amino acids that contribute to the molecule's charge:
pKR = {'y': 10.07, 'c': 8.18, 'k': 10.53, 'h': 6.00, 'r': 12.48, 'd': 3.65, 'e': 4.25}

# Count the occurrences of charge-contributing amino acids in the insulin sequence:
seqCount = {x: float(insulin.count(x)) for x in ['y', 'c', 'k', 'h', 'r', 'd', 'e']}

# Loop through different pH levels and calculate the net charge of the insulin molecule:
pH = 0
while pH <= 14:
    # Calculate positive charge contribution (from k, h, r)
    positive_charge = sum((seqCount[x] * (10**pKR[x])) / ((10**pH) + (10**pKR[x])) for x in ['k', 'h', 'r'])
    
    # Calculate negative charge contribution (from y, c, d, e)
    negative_charge = sum((seqCount[x] * (10**pH)) / ((10**pH) + (10**pKR[x])) for x in ['y', 'c', 'd', 'e'])
    
    # Net charge is positive charge minus negative charge
    netCharge = positive_charge - negative_charge
    
    # Print the pH and the corresponding net charge (formatted to 2 decimal places)
    print(f"pH {pH:.2f}: Net Charge = {netCharge:.2f}")
    
    # Increment pH by 1 for the next iteration
    pH += 1

