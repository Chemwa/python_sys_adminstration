import json

def readJsonFile(fileName):
    data = ""
    try:
        with open(fileName, 'r') as json_file:  # Use the fileName parameter
            data = json.load(json_file)  # Load the JSON file
    except IOError:
        print("Could not read file")
    return data  # The return statement should be outside the except block

