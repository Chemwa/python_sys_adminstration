#def demo(x):
    #y=x+3
   # return(y)
#print(demo(3))


a = 1
b = 3
c = 4

def demo():
    y = a + b + c
    print(y)  # Add this to display the result of the calculation

demo()  # Call the function to execute it
     
def ugali_flavor(x):
    ugali = "water + flour + " + x
    return ugali
print (ugali_flavor("pink flavor"))
 
def goodboy():
    good=" hardwork " + " determination " + " focus "
    return good
    
print(goodboy())
goodboy()


def bios():
    system_bios="The ability of " + "the laptop to power on well"
    return(system_bios)
print(bios())

def age():
    y=2002
    x=2024
    RealAge=x-y
    return RealAge
print(age())




