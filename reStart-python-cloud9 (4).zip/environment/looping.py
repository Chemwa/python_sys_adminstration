counter = 0
 
while(counter <= 3):
    print(f"I love learning python {counter}")
    counter = counter + 1