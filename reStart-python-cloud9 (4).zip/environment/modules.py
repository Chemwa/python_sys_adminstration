#import math
#result=math.sqrt(int(input("Enter number")))
#print (result)

import math
absolute=-19
floor_t=67
output1=math.fabs(absolute)
output2=math.floor(floor_t)
print(output1, 'is the abs value', absolute)
print(output2, 'is the abs value', floor_t)


